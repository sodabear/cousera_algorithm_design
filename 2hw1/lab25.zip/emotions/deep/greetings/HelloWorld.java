package greetings;
import gratitude.ThankYou;
public class HelloWorld {

    public ThankYou mySincerestApologies;

    public static void main(String[] args) {
        System.out.println("Thanks for everything, world!");
    }
}
