package enigma;
public class EnigmaException extends RuntimeException {
    public EnigmaException() {
    }

    public EnigmaException(String msg) {
        super(msg);
    }
}
