import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		while (true) {
			Scanner s = new Scanner(System.in);
			int x = Integer.parseInt(s.next());
			System.out.println(x);
		}
	}
}
