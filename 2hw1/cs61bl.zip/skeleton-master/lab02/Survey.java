public class Survey {

    public String getSecretWord() {
        return "PUT SECRET WORD HERE!";
    }
}
