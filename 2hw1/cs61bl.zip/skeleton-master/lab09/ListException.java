public class ListException extends RuntimeException {
    public ListException(String message) {
        super(message);
    }
}