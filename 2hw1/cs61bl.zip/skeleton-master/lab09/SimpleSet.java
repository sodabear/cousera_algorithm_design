public interface SimpleSet extends SimpleCollection {

	// THERE IS NOTHING HERE!
	// As we have described sets to you for this lab, the
	// requirements for a set are the same as the requirements
	// for a collection. In the actual Java implementation of
	// Set and Collection, this is not true, but we are not 
	// having you implement all the (many) methods of the actual
	// Set and List classes. If this is disappointing, look at 
	// SimpleList, which does have additional requirements!
}