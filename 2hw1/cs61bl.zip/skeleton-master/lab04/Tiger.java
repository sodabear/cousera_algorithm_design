public class Tiger extends Cat{

	public void method3() {
		System.out.println("Tiger: method3");		
	}

	public void method5() {
		System.out.println("Tiger: method5");		
	}

	public void method6() {
		System.out.println("Tiger: method6");		
	}

	public void method7() {
		System.out.println("Tiger: method7");		
	}

}
